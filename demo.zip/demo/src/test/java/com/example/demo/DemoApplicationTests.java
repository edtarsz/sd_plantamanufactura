package com.example.demo;

import com.example.notificacions.NotificacionesApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = NotificacionesApplication.class)
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
