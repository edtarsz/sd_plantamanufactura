package com.example.notificaciones.model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author crist
 */
import lombok.Data;

@Data
public class Notificacion {
    private String message;
}
