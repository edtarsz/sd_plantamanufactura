package com.example.notificacions;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class NotificacionesApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificacionesApplication.class, args);
    }

    @Bean
    public CommandLineRunner printPort(Environment env) {
        return args -> {
            String port = env.getProperty("server.port");
            System.out.println("🟢 Puerto actual configurado: " + port);
        };
    }
    
    @Bean
    public ApplicationRunner printConfigPort(Environment env) {
        return args -> {
         System.out.println("🔥 server.port desde configuración cargada: " + env.getProperty("server.port"));
        };
    }

}
